using UnityEngine;

public class AutomaticExample : MonoBehaviour
{
    void Awake()
    { // Practicamente se inicializan las propiedades del componente
        DialogueTrigger trigger = gameObject.AddComponent<DialogueTrigger>();
        trigger.sequenceId = "area_intro";
        trigger.triggerType = DialogueTrigger.TriggerType.PlayerEnter; // Trigger al entrar en �rea direfencia de distancias; como jugador
        trigger.triggerOnce = true; // Una vez
    }
}
