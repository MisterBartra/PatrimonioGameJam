using UnityEngine;

public class ClickableExample : MonoBehaviour
{
    void Awake() { // Practicamente se inicializan las propiedades del componente
        Interactable interactable = gameObject.AddComponent<Interactable>();
        interactable.sequenceId = "object_description";
        interactable.requiresPlayer = false; // Para objetos clickeables sin jugador
    }
}
