using UnityEngine;

public class DefaultNPCDialogue : MonoBehaviour
{
    void Start()
    {
        // En el GameObject del NPC
        Interactable npc = gameObject.AddComponent<Interactable>();
        npc.sequenceId = "npc_greeting";
        npc.interactionKey = KeyCode.E;
        npc.interactionRange = 3f;
    }
}
