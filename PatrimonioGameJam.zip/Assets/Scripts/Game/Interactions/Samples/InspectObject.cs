using UnityEngine;

public class InspectObject : MonoBehaviour
{
    void executeFunction()
    { // o Awake
        // En el GameObject del NPC
        Interactable npc = gameObject.AddComponent<Interactable>(); // Esto solo hace que uno no necesite arrastrar del Componente inteligente en el inspector
        npc.sequenceId = "npc_greeting";
        npc.interactionKey = KeyCode.E;
        npc.interactionRange = 3f;
    }
}
