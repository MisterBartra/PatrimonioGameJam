using UnityEngine;

public class InteractionExample : MonoBehaviour
{
    void Awake() { // Practicamente se inicializan las propiedades del componente
        Interactable interactable = gameObject.AddComponent<Interactable>(); // Sin necesidad de asignarlo, se lo hace solo in-game
        interactable.sequenceId = "quest_dialogue";
        interactable.interactionKey = KeyCode.E;
        interactable.interactionRange = 2f;
        interactable.requiresPlayer = true;
    }
}
