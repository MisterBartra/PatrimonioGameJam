using UnityEngine;

public class AutomaticSceneTransition : MonoBehaviour
{
    void executeFunction()
    {
        // Trigger que cambia de escena autom�ticamente
        DialogueTrigger trigger = gameObject.AddComponent<DialogueTrigger>();
        trigger.sequenceId = "scene_transition";
        trigger.triggerType = DialogueTrigger.TriggerType.PlayerEnter;
    }
}
