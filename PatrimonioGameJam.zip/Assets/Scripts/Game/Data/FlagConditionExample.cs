using UnityEngine;

public class FlagConditionExample : MonoBehaviour
{
    void executeFunction()
    {
        // Establece flag
        GameStateManager.Instance.SetFlag("hasITEMNAME", false);
        // Verifica flag
        bool hasTalked = GameStateManager.Instance.HasFlag("hasITEMNAME");
        // Siendo statics entonces se invocan donde se necesite. Deber�an poder invocarse desde cualquier otro script que se cree.
    }
}
