using UnityEngine;

public class VariableConditionExample : MonoBehaviour
{
    void Start()
    {
        // Guardar variables
        GameStateManager.Instance.SetVariable("playerName", "PlayerName");
        // Obtener variables
        string name = GameStateManager.Instance.GetVariable<string>("playerName", "Player"); // Si ni coincide retorna el valor del dato como segundo argumento(seg�n su dato),del que se puso ah�.
        // Funcional tambi�n con datos de tipos number.
        // Lo mismo que como en flag, solo que aca se consegue y comparan datos para hacer flujo de condiciones.
    }
}
