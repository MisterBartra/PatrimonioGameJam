using UnityEngine;

public class GoToCutSceneDialog : MonoBehaviour
{
    void executeFunction()
    {// Para intros o cutscenes
        AutoDialogueStarter starter = gameObject.AddComponent<AutoDialogueStarter>();
        starter.sequenceIds = new string[] { "intro_1", "intro_2", "intro_3" };
        starter.delays = new float[] { 0f, 2f, 1f }; // Opcional no indicarse para que no avance luego de unos segundos.
        starter.playSequentially = true; // Se mueva en secuencia
    }
}