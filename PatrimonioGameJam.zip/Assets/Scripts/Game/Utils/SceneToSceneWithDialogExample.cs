using UnityEngine;

public class SceneToSceneWithDialogExample : MonoBehaviour
{
    void action() // Algo que se hace y que luego necesites salir de la escena actual y pasar a una siguiente con fondos y sequencias (con dialogos)
    {
        // Desde cualquier script
        BartraSceneUtils.GoToSceneWithSequence("SlideScene", "quest_dialogue");
    }
}
