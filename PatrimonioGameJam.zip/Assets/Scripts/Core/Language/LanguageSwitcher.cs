using UnityEngine;
using UnityEngine.UI;

public class LanguageSwitcher : MonoBehaviour
{
    [Header("UI References")]
    public Button englishButton;
    public Button spanishButton;
    public Button[] additionalLanguageButtons;
    public string[] additionalLanguageCodes;

    private void Start()
    {
        // Configurar botones adicionales
        for (int i = 0; i < additionalLanguageButtons.Length && i < additionalLanguageCodes.Length; i++)
        {
            string langCode = additionalLanguageCodes[i];
            additionalLanguageButtons[i].onClick.AddListener(() => SwitchLanguage(langCode));
        }
    }

    public void SwitchLanguage(string languageCode)
    {
        if (LanguageManager.Instance != null)
        {
            LanguageManager.Instance.SetLanguage(languageCode);

            // Guardar preferencia
            PlayerPrefs.SetString("PreferredLanguage", languageCode);
            PlayerPrefs.Save();
        }
    }

    private void Awake()
    {
        // Cargar idioma guardado
        string savedLanguage = PlayerPrefs.GetString("PreferredLanguage", "en");
        if (LanguageManager.Instance != null)
        {
            LanguageManager.Instance.SetLanguage(savedLanguage);
        }
    }

    /* Desde c�digo
    LanguageManager.Instance.SetLanguage("es"); p*/
}