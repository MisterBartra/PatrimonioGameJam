using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;

public class LanguageManager : MonoBehaviour
{
    public static LanguageManager Instance;

    public event System.Action OnLanguageChanged;

    private Dictionary<string, Dictionary<string, string>> _languages = new();
    private string _currentLanguage = "en";
    private const string FALLBACK_LANGUAGE = "en";

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            LoadLanguages();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void LoadLanguages()
    {
        string path = Path.Combine(Application.streamingAssetsPath, "Languages");
        if (!Directory.Exists(path)) return;

        string[] files = Directory.GetFiles(path, "*.json");
        foreach (string file in files)
        {
            string langCode = Path.GetFileNameWithoutExtension(file);
            try
            {
                string content = File.ReadAllText(file);
                var translations = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);
                _languages[langCode] = translations;
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Error loading language {langCode}: {e.Message}");
            }
        }
    }

    public void SetLanguage(string languageCode)
    {
        if (_languages.ContainsKey(languageCode))
        {
            _currentLanguage = languageCode;
            OnLanguageChanged?.Invoke();
        }
        else
        {
            Debug.LogWarning($"Language {languageCode} not found, using fallback");
        }
    }

    public string GetTranslation(string key)
    {
        // Buscar en idioma actual
        if (_languages.ContainsKey(_currentLanguage) &&
            _languages[_currentLanguage].ContainsKey(key))
        {
            return _languages[_currentLanguage][key];
        }

        // Fallback a ingl�s
        if (_currentLanguage != FALLBACK_LANGUAGE &&
            _languages.ContainsKey(FALLBACK_LANGUAGE) &&
            _languages[FALLBACK_LANGUAGE].ContainsKey(key))
        {
            return _languages[FALLBACK_LANGUAGE][key];
        }

        return $"[{key}]";
    }
}
