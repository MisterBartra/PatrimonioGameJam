using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class LocalizedText : MonoBehaviour
{
    [SerializeField] private string key;
    [SerializeField] private bool useTextMeshPro = true;

    private Text _legacyText;
    private TextMeshProUGUI _tmpText;

    private void Awake()
    {
        if (useTextMeshPro)
            _tmpText = GetComponent<TextMeshProUGUI>();
        else
            _legacyText = GetComponent<Text>();
    }

    private void OnEnable()
    {
        if (LanguageManager.Instance != null)
            LanguageManager.Instance.OnLanguageChanged += UpdateText;
        UpdateText();
    }

    private void OnDisable()
    {
        if (LanguageManager.Instance != null)
            LanguageManager.Instance.OnLanguageChanged -= UpdateText;
    }

    private void UpdateText()
    {
        if (string.IsNullOrEmpty(key)) return;

        string translatedText = LanguageManager.Instance?.GetTranslation(key) ?? $"[{key}]";

        if (_tmpText != null)
            _tmpText.text = translatedText;
        else if (_legacyText != null)
            _legacyText.text = translatedText;
    }

    public void SetKey(string newKey)
    {
        key = newKey;
        UpdateText();
    }
}
