using UnityEngine;

public class DialogueTrigger : MonoBehaviour
{
    [Header("Trigger Settings")]
    public string sequenceId;
    public TriggerType triggerType = TriggerType.PlayerEnter;
    public bool triggerOnce = true;

    [Header("Conditions")]
    public string[] requiredFlags;
    public string[] prohibitedFlags;

    private bool _hasTriggered;

    public enum TriggerType
    {
        PlayerEnter,
        PlayerStay,
        Click,
        Automatic
    }

    private void Start()
    {
        if (triggerType == TriggerType.Automatic)
        {
            TriggerDialogue();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (triggerType == TriggerType.PlayerEnter && other.CompareTag("Player"))
        {
            TriggerDialogue();
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (triggerType == TriggerType.PlayerStay && other.CompareTag("Player") && Input.GetKeyDown(KeyCode.E))
        {
            TriggerDialogue();
        }
    }

    private void OnMouseDown()
    {
        if (triggerType == TriggerType.Click)
        {
            TriggerDialogue();
        }
    }

    private void TriggerDialogue()
    {
        if (_hasTriggered && triggerOnce) return;
        if (!CheckConditions()) return;

        DialogueSequence sequence = DialogueDataManager.Instance.GetSequence(sequenceId);
        if (sequence.entries != null && sequence.entries.Count > 0)
        {
            DialogueManager.Instance.StartSequence(sequence);
            _hasTriggered = true;
        }
    }

    private bool CheckConditions()
    {
        // Verificar flags requeridas
        foreach (string flag in requiredFlags)
        {
            if (!GameStateManager.Instance.HasFlag(flag))
                return false;
        }

        // Verificar flags prohibidas
        foreach (string flag in prohibitedFlags)
        {
            if (GameStateManager.Instance.HasFlag(flag))
                return false;
        }

        return true;
    }
}