using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using UnityEngine;

public class DialogueDataManager : MonoBehaviour
{
    public static DialogueDataManager Instance;

    private Dictionary<string, DialogueSequence> _sequences = new();
    private Dictionary<string, SceneNavigation> _navigations = new();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            LoadData();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void LoadData()
    {
        LoadSequences();
        LoadNavigations();
    }

    private void LoadSequences()
    {
        string path = Path.Combine(Application.streamingAssetsPath, "dialogue_sequences.json");
        if (File.Exists(path))
        {
            try
            {
                string content = File.ReadAllText(path);
                var sequences = JsonConvert.DeserializeObject<List<DialogueSequence>>(content);
                foreach (var seq in sequences)
                {
                    _sequences[seq.sequenceId] = seq;
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Error loading dialogue sequences: {e.Message}");
            }
        }
    }

    private void LoadNavigations()
    {
        string path = Path.Combine(Application.streamingAssetsPath, "scene_navigation.json");
        if (File.Exists(path))
        {
            try
            {
                string content = File.ReadAllText(path);
                var navigations = JsonConvert.DeserializeObject<List<SceneNavigation>>(content);
                foreach (var nav in navigations)
                {
                    _navigations[$"{nav.fromScene}_{nav.toScene}"] = nav;
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Error loading scene navigation: {e.Message}");
            }
        }
    }

    public DialogueSequence GetSequence(string sequenceId)
    {
        _sequences.TryGetValue(sequenceId, out DialogueSequence sequence);
        return sequence;
    }

    public SceneNavigation GetNavigation(string fromScene, string toScene)
    {
        _navigations.TryGetValue($"{fromScene}_{toScene}", out SceneNavigation navigation);
        return navigation;
    }
}