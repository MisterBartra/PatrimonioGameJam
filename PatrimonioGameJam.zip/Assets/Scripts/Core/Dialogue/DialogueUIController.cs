using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class DialogueUIController : MonoBehaviour
{
    [Header("UI Animation")]
    public CanvasGroup dialogueCanvasGroup;
    public float fadeInDuration = 0.5f;
    public float fadeOutDuration = 0.3f;

    [Header("Character Animation")]
    public Transform characterContainer;
    public AnimationCurve characterEntryAnimation;

    [Header("Background Transition")]
    public Image backgroundImage;
    public float backgroundTransitionDuration = 1f;

    private void Start()
    {
        if (DialogueManager.Instance != null)
        {
            DialogueManager.Instance.OnSequenceComplete += OnDialogueComplete;
        }
    }

    public void ShowDialogue()
    {
        StartCoroutine(FadeIn());
    }

    public void HideDialogue()
    {
        StartCoroutine(FadeOut());
    }

    private IEnumerator FadeIn()
    {
        dialogueCanvasGroup.gameObject.SetActive(true);
        float elapsed = 0f;

        while (elapsed < fadeInDuration)
        {
            elapsed += Time.deltaTime;
            dialogueCanvasGroup.alpha = Mathf.Lerp(0f, 1f, elapsed / fadeInDuration);
            yield return null;
        }

        dialogueCanvasGroup.alpha = 1f;
    }

    private IEnumerator FadeOut()
    {
        float elapsed = 0f;

        while (elapsed < fadeOutDuration)
        {
            elapsed += Time.deltaTime;
            dialogueCanvasGroup.alpha = Mathf.Lerp(1f, 0f, elapsed / fadeOutDuration);
            yield return null;
        }

        dialogueCanvasGroup.alpha = 0f;
        dialogueCanvasGroup.gameObject.SetActive(false);
    }

    public void TransitionBackground(Sprite newBackground)
    {
        if (newBackground != null)
        {
            StartCoroutine(BackgroundTransition(newBackground));
        }
    }

    private IEnumerator BackgroundTransition(Sprite newSprite)
    {
        Image tempImage = Instantiate(backgroundImage, backgroundImage.transform.parent);
        tempImage.sprite = newSprite;
        tempImage.color = new Color(1, 1, 1, 0);

        float elapsed = 0f;
        while (elapsed < backgroundTransitionDuration)
        {
            elapsed += Time.deltaTime;
            float alpha = Mathf.Lerp(0f, 1f, elapsed / backgroundTransitionDuration);
            tempImage.color = new Color(1, 1, 1, alpha);
            yield return null;
        }

        backgroundImage.sprite = newSprite;
        backgroundImage.color = Color.white;
        Destroy(tempImage.gameObject);
    }

    private void OnDialogueComplete(string sequenceId)
    {
        HideDialogue();
    }

    private void OnDestroy()
    {
        if (DialogueManager.Instance != null)
        {
            DialogueManager.Instance.OnSequenceComplete -= OnDialogueComplete;
        }
    }
}
