using UnityEngine;

public class ConditionalDialogue : MonoBehaviour
{
    [System.Serializable]
    public struct DialogueCondition
    {
        public string sequenceId; public string[] requiredFlags, prohibitedFlags;
        public int minLevel, maxLevel;
    }

    [Header("Dialogue Conditions")]
    public DialogueCondition[] conditions;
    public string defaultSequenceId;

    public string GetValidSequenceId()
    {
        foreach (var condition in conditions)
        {
            if (CheckCondition(condition))
            {
                return condition.sequenceId;
            }
        }

        return defaultSequenceId;
    }

    private bool CheckCondition(DialogueCondition condition)
    {
        // Verificar flags requeridas
        foreach (string flag in condition.requiredFlags)
        {
            if (!GameStateManager.Instance.HasFlag(flag))
                return false;
        }

        // Verificar flags prohibidas
        foreach (string flag in condition.prohibitedFlags)
        {
            if (GameStateManager.Instance.HasFlag(flag))
                return false;
        }

        // Verificar nivel si se especifica
        if (condition.minLevel > 0 || condition.maxLevel > 0)
        {
            int playerLevel = GameStateManager.Instance.GetVariable<int>("playerLevel", 1);
            if (condition.minLevel > 0 && playerLevel < condition.minLevel)
                return false;
            if (condition.maxLevel > 0 && playerLevel > condition.maxLevel)
                return false;
        }

        return true;
    }

    public void TriggerConditionalDialogue()
    {
        string sequenceId = GetValidSequenceId();
        if (!string.IsNullOrEmpty(sequenceId))
        {
            DialogueSequence sequence = DialogueDataManager.Instance.GetSequence(sequenceId);
            if (sequence.entries != null && sequence.entries.Count > 0)
            {
                DialogueManager.Instance.StartSequence(sequence);
            }
        }
    }
}