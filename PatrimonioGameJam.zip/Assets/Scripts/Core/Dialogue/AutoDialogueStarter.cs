using UnityEngine;
using System.Collections;

public class AutoDialogueStarter : MonoBehaviour
{
    [Header("Auto Start Settings")]
    public string[] sequenceIds;
    public float[] delays;
    public bool playSequentially = true;
    public bool waitForPreviousComplete = true;

    private int _currentSequenceIndex;
    private bool _isPlaying;

    private void Start()
    {
        if (sequenceIds.Length > 0)
        {
            StartCoroutine(StartDialogueSequence());
        }
    }

    private IEnumerator StartDialogueSequence() // Aqu� es una Corutina en lugar de un evento ya que lo tengo m�s comprendido, puede que estudie del Evento luego.
    {
        _isPlaying = true;

        for (int i = 0; i < sequenceIds.Length; i++)
        {
            _currentSequenceIndex = i;

            // Esperar delay si se especifica
            if (delays.Length > i && delays[i] > 0)
            {
                yield return new WaitForSeconds(delays[i]);
            }

            // Iniciar secuencia
            DialogueSequence sequence = DialogueDataManager.Instance.GetSequence(sequenceIds[i]);
            if (sequence.entries != null && sequence.entries.Count > 0)
            {
                DialogueManager.Instance.StartSequence(sequence);

                // Esperar a que termine si est� configurado
                if (waitForPreviousComplete)
                {
                    bool sequenceComplete = false;
                    System.Action<string> onComplete = (id) => {
                        if (id == sequenceIds[i]) sequenceComplete = true;
                    };

                    DialogueManager.Instance.OnSequenceComplete += onComplete;
                    yield return new WaitUntil(() => sequenceComplete);
                    DialogueManager.Instance.OnSequenceComplete -= onComplete;
                }
            }

            if (!playSequentially) break;
        }

        _isPlaying = false;
    }

    public void StopSequence()
    {
        _isPlaying = false;
        StopAllCoroutines();
    }
}
