using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManager : MonoBehaviour
{
    public static DialogueManager Instance;

    [Header("UI References")]
    public Canvas dialogueCanvas;
    public Image textBoxImage;
    public TextMeshProUGUI dialogueText;
    public Image characterImage;
    public Image backgroundImage;
    public Button nextButton;

    [Header("Settings")]
    public float defaultTextSpeed = 0.05f;
    public AnimationCurve fadeTransition;

    private DialogueSequence _currentSequence;
    private int _currentEntryIndex;
    private bool _isTyping;
    private AudioSource _audioSource;
    private Coroutine _typingCoroutine;

    public event System.Action<string> OnSequenceComplete;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            _audioSource = GetComponent<AudioSource>();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        dialogueCanvas.gameObject.SetActive(false);
        nextButton.onClick.AddListener(NextEntry);
    }

    public void StartSequence(DialogueSequence sequence)
    {
        _currentSequence = sequence;
        _currentEntryIndex = 0;
        dialogueCanvas.gameObject.SetActive(true);
        ShowCurrentEntry();
    }

    private void ShowCurrentEntry()
    {
        if (_currentEntryIndex >= _currentSequence.entries.Count)
        {
            EndSequence();
            return;
        }

        DialogueEntry entry = _currentSequence.entries[_currentEntryIndex];

        // Actualizar elementos visuales
        UpdateVisuals(entry);

        // Iniciar tipeo de texto
        if (_typingCoroutine != null) StopCoroutine(_typingCoroutine);
        _typingCoroutine = StartCoroutine(TypeText(entry));
    }

    private void UpdateVisuals(DialogueEntry entry)
    {
        // Actualizar sprites si se especifican
        if (!string.IsNullOrEmpty(entry.characterSprite))
        {
            Sprite charSprite = Resources.Load<Sprite>($"Characters/{entry.characterSprite}");
            if (charSprite) characterImage.sprite = charSprite;
            characterImage.rectTransform.anchoredPosition = entry.characterPosition;
        }

        if (!string.IsNullOrEmpty(entry.backgroundSprite))
        {
            Sprite bgSprite = Resources.Load<Sprite>($"Backgrounds/{entry.backgroundSprite}");
            if (bgSprite) backgroundImage.sprite = bgSprite;
        }

        // Cambiar m�sica si se especifica
        if (!string.IsNullOrEmpty(entry.musicClip))
        {
            AudioClip clip = Resources.Load<AudioClip>($"Music/{entry.musicClip}");
            if (clip && _audioSource)
            {
                _audioSource.clip = clip;
                _audioSource.Play();
            }
        }
    }

    private IEnumerator TypeText(DialogueEntry entry)
    {
        _isTyping = true;
        string fullText = LanguageManager.Instance.GetTranslation(entry.textKey);
        dialogueText.text = "";

        float speed = entry.textSpeed > 0 ? entry.textSpeed : defaultTextSpeed;

        foreach (char letter in fullText)
        {
            dialogueText.text += letter;
            yield return new WaitForSeconds(speed);
        }

        _isTyping = false;
    }

    public void NextEntry()
    {
        if (_isTyping)
        {
            // Completar texto inmediatamente
            if (_typingCoroutine != null) StopCoroutine(_typingCoroutine);
            DialogueEntry entry = _currentSequence.entries[_currentEntryIndex];
            dialogueText.text = LanguageManager.Instance.GetTranslation(entry.textKey);
            _isTyping = false;
            return;
        }

        _currentEntryIndex++;
        ShowCurrentEntry();
    }

    private void EndSequence()
    {
        dialogueCanvas.gameObject.SetActive(false);
        OnSequenceComplete?.Invoke(_currentSequence.sequenceId);

        // Navegar a siguiente escena o secuencia
        if (!string.IsNullOrEmpty(_currentSequence.nextScene))
        {
            BartraSceneUtils.GoToScene(_currentSequence.nextScene);
        }
    }

    private void Update()
    {
        if (dialogueCanvas.gameObject.activeInHierarchy &&
            (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return) || Input.GetMouseButtonDown(0)))
        {
            NextEntry();
        }
    }
}