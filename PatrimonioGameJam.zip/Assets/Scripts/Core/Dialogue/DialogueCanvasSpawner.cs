using UnityEngine;

public class DialogueCanvasSpawner : MonoBehaviour
{
    [Header("Prefab Settings")]
    public GameObject dialogueCanvasPrefab;
    public bool spawnOnStart = true;
    public bool destroyOnSceneChange = false;

    private GameObject _spawnedCanvas;

    private void Start()
    {
        if (spawnOnStart)
        {
            SpawnDialogueCanvas();
        }
    }

    public void SpawnDialogueCanvas()
    {
        if (_spawnedCanvas != null) return;

        if (dialogueCanvasPrefab != null)
        {
            _spawnedCanvas = Instantiate(dialogueCanvasPrefab);

            if (!destroyOnSceneChange)
            {
                DontDestroyOnLoad(_spawnedCanvas);
            }
        }
        else
        {
            Debug.LogWarning("Dialogue Canvas Prefab is not assigned!");
        }
    }

    public void DestroyDialogueCanvas()
    {
        if (_spawnedCanvas != null)
        {
            Destroy(_spawnedCanvas);
            _spawnedCanvas = null;
        }
    }
}
