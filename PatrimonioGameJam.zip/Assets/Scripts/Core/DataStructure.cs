using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public struct DialogueEntry
{
    public string textKey;
    public string characterName;
    public string characterSprite;
    public Vector2 characterPosition;
    public string backgroundSprite;
    public string musicClip;
    public float textSpeed;
    public bool waitForInput;
}

[Serializable]
public struct DialogueSequence
{
    public string sequenceId;
    public string nextScene;
    public string nextSequence;
    public List<DialogueEntry> entries;
    public bool useGradientTransition;
    public float transitionDuration;
}

[Serializable]
public struct SceneNavigation
{
    public string fromScene;
    public string toScene;
    public string triggerSequence;
    public Vector3 playerSpawnPosition;
    public Dictionary<string, object> conditions;
}
