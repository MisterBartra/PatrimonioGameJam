using System.Collections.Generic;
using UnityEngine;

public class GameStateManager : MonoBehaviour
{
    public static GameStateManager Instance;

    private HashSet<string> _flags = new HashSet<string>();
    private Dictionary<string, object> _variables = new Dictionary<string, object>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SetFlag(string flag, bool value = true)
    {
        if (value)
            _flags.Add(flag);
        else
            _flags.Remove(flag);
    }

    public bool HasFlag(string flag)
    {
        return _flags.Contains(flag);
    }

    public void SetVariable<T>(string key, T value)
    {
        _variables[key] = value;
    }

    public T GetVariable<T>(string key, T defaultValue = default(T))
    {
        if (_variables.TryGetValue(key, out object value) && value is T)
        {
            return (T)value;
        }
        return defaultValue;
    }

    public void ClearFlag(string flag)
    {
        _flags.Remove(flag);
    }

    public void ClearAllFlags()
    {
        _flags.Clear();
    }
}

