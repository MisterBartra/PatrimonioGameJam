using UnityEngine;
using System.Collections;

public class SceneLoaderWithDialogue : MonoBehaviour
{
    [Header("Loading Settings")]
    public string loadingSequenceId = "scene_transition";
    public float minimumLoadingTime = 2f;

    private bool _isLoading;

    public void LoadSceneWithDialogue(string sceneName, string sequenceId = "")
    {
        if (_isLoading) return;

        StartCoroutine(LoadSequence(sceneName, sequenceId));
    }

    private IEnumerator LoadSequence(string sceneName, string sequenceId)
    {
        _isLoading = true;

        // Mostrar di�logo de transici�n si existe
        if (!string.IsNullOrEmpty(loadingSequenceId))
        {
            DialogueSequence loadingSequence = DialogueDataManager.Instance.GetSequence(loadingSequenceId);
            if (loadingSequence.entries != null && loadingSequence.entries.Count > 0)
            {
                DialogueManager.Instance.StartSequence(loadingSequence);
            }
        }

        // Esperar tiempo m�nimo de carga
        yield return new WaitForSeconds(minimumLoadingTime);

        // Cargar escena con secuencia pendiente si se especifica
        if (!string.IsNullOrEmpty(sequenceId))
        {
            BartraSceneUtils.GoToSceneWithSequence(sceneName, sequenceId);
        }
        else
        {
            BartraSceneUtils.GoToScene(sceneName);
        }
    }
}