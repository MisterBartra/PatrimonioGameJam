using UnityEngine;
using UnityEngine.SceneManagement;

public static class BartraSceneUtils
{
    public static void RetryScene() => SceneManager.LoadScene(SceneManager.GetActiveScene().name);

    public static void GoToScene(string sceneName) => SceneManager.LoadScene(sceneName);

    public static void GoToSceneWithSequence(string sceneName, string sequenceId)
    {
        PlayerPrefs.SetString("PendingSequence", sequenceId);
        SceneManager.LoadScene(sceneName);
    }

    public static string GetPendingSequence()
    {
        string sequence = PlayerPrefs.GetString("PendingSequence", "");
        if (!string.IsNullOrEmpty(sequence))
        {
            PlayerPrefs.DeleteKey("PendingSequence");
        }
        return sequence;
    }
}
