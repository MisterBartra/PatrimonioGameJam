using UnityEngine;
using System.Collections;

public class SlideSceneController : MonoBehaviour
{
    [Header("Slide Settings")]
    public bool autoStart = true;
    public string initialSequenceId;

    private void Start()
    {
        // Verificar si hay una secuencia pendiente
        string pendingSequence = BartraSceneUtils.GetPendingSequence();

        if (!string.IsNullOrEmpty(pendingSequence))
        {
            StartCoroutine(DelayedStart(pendingSequence));
        }
        else if (autoStart && !string.IsNullOrEmpty(initialSequenceId))
        {
            StartCoroutine(DelayedStart(initialSequenceId));
        }
    }

    private IEnumerator DelayedStart(string sequenceId)
    {
        yield return new WaitForSeconds(0.1f); // Peque�o delay para asegurar inicializaci�n

        DialogueSequence sequence = DialogueDataManager.Instance.GetSequence(sequenceId);
        if (sequence.entries != null && sequence.entries.Count > 0)
        {
            DialogueManager.Instance.StartSequence(sequence);
        }
    }
}