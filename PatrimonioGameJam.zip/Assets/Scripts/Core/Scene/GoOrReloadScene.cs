using UnityEngine;

public class GoOrReloadScene : MonoBehaviour
{
    public void GoToScene(string sceneName) => BartraSceneUtils.GoToScene(sceneName);
    public void RetryScene() => BartraSceneUtils.RetryScene();

}
