using UnityEngine;

public class Interactable : MonoBehaviour
{
    [Header("Interaction Settings")]
    public string sequenceId;
    public KeyCode interactionKey = KeyCode.E;
    public float interactionRange = 2f;
    public bool requiresPlayer = true;

    [Header("Visual Feedback")]
    public GameObject promptUI;

    private bool _playerInRange;
    private Transform _player;

    private void Start()
    {
        if (requiresPlayer)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj) _player = playerObj.transform;
        }

        if (promptUI) promptUI.SetActive(false);
    }

    private void Update()
    {
        if (requiresPlayer && _player)
        {
            float distance = Vector3.Distance(transform.position, _player.position);
            bool inRange = distance <= interactionRange;

            if (inRange != _playerInRange)
            {
                _playerInRange = inRange;
                if (promptUI) promptUI.SetActive(_playerInRange);
            }

            if (_playerInRange && Input.GetKeyDown(interactionKey))
            {
                Interact();
            }
        }
    }

    private void OnMouseDown()
    {
        if (!requiresPlayer)
        {
            Interact();
        }
    }

    public void Interact()
    {
        if (!string.IsNullOrEmpty(sequenceId))
        {
            DialogueSequence sequence = DialogueDataManager.Instance.GetSequence(sequenceId);
            if (sequence.entries != null && sequence.entries.Count > 0)
            {
                DialogueManager.Instance.StartSequence(sequence);
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        if (requiresPlayer)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, interactionRange);
        }
    }
}